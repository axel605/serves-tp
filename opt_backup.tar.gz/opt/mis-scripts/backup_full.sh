#!/bin/bash
mensaje_de_ayuda(){
echo "Seusa: $0 [origen] [destino]"
echo "$0 sirve para realizar un backup de los directorios seleccionados"
echo "ARGUMENTOS:"
echo "	[Origen]: Directorio a copiar"
echo "	[Destino]: Direccion de donde se guarda el bacukp"
echo "Opciones: "
echo "	-h: Mostrar ayuda"
}
#comprueba si se ingreso  el parametro -h
if [ "$#" -eq 1 ] && [ "$1" == "-h" ]; then #-ep = igual a (==)
	mensaje_de_ayuda
	exit 0
fi
#comprueba si estan los 2 argumentos
if [ "$#" -ne 2 ]; then # -ne = no es igual (!=)
	echo "Error: se necesita 2 argumentos"
	echo "-h: mostrar ayuda"
	exit 1
fi
origen="$1"
destino="$2"
# buscamos si los argumentos estan montados
if mountpoint -q "$origen"; then

	if ! mountpoint -q "$origen"; then
        	echo "Error: '$origen' no esta montado"
        	exit 1
	fi
	if [ ! -d "$origen" ]; then
        	echo "Error: '$origen' no existe o no es un directorio"
        	exit 1
	fi
fi

if ! mountpoint -q "$destino"; then
        echo "Error: '$destino' no esta montado"
        exit 1
fi
#guardamos la fecha en una variable que guarda con el formato YYYYMMDD
fecha=$(date +%Y%m%d)

nombre_backup="$(basename "$origen")_bkp_$fecha.tar.gz"
#basename = perpite obtener el nombre del archivo de una dirreccion 

#tar = comando para comprimir archivos
tar -czf "$destino/$nombre_backup" -C "$origen" .
#-c: creas el archivo .tar
#-z: comprimes el archivo a .gz
#-f: le das un nombre al archivo
#-C: cambiamos la direccion del archivo durante el empaquetamiento
if [ $? -eq 0 ]; then   # $? = el valor del código de salida del último comando ejecutado (tar)
    echo "Backup realizado exitosamente: $destino$nombre_backup"  # Mensaje de éxito si tar se ejecutó correctamente
else
    echo "Error al realizar el backup."  # Mensaje de error si hubo un problema al ejecutar tar
fi
